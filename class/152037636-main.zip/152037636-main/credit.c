#include <cs50.h>
#include <stdio.h>
#include <math.h>

int main(void)
{
int cdc;

{
    cdc = get_int("Código do cartão: ");
}
}
