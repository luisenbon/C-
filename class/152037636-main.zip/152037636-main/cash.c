 #include <cs50.h>
 #include <stdio.h>
 #include <math.h>

 int main(void)
 {

 float troco;
 int moedas25, moedas10, moedas5, moedas1;
 int 25
