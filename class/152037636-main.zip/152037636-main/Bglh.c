#include <cs50.h>
#include <stdio.h>

int x
{
x=get_int("Manda o numero burrão: ");
printf("%i", x*2);



}
