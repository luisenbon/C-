#include <stdio.h>
#include <cs50.h>

int main (void)
{
long long cc, cca, div;
int s1=0, s2=0, sf=0;
    do
    {
    cc=get_long("Qual o codigo o xará? ");
    }
    while(cc>1);
    
}
