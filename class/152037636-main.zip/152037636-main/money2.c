#include <stdio.h>
#include <cs50.h>

int main (void)
{
    float troco;
    int m25, m10, m5, m1
    int moeda25, moeda10, moeda5, moeda1
}
